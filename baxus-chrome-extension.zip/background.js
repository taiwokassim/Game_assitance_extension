chrome.runtime.onInstalled.addListener(() => {
  console.log("BAXUS Comparator Extension Installed.");
});